$(document).ready(function(){

   $("#variant1").click(function(){
    $("#variant-choose").text("Choose your variant");
  });
  $("#variant2").click(function(){
    $("#variant-choose").text("Choose your color");
  });
  $("#variant3").click(function(){
    $("#variant-choose").text("Choose your Accessories");
  });
  $("#variant4").click(function(){
    $("#variant-choose").text("Choose your Extended Waranty");
  });
  $("#variant5").click(function(){
    $("#variant-choose").text("Choose your insurance");
  });
 $("#variant6").click(function(){
    $("#variant-choose").text("Choose your loan");
  });
  

 $("#variant-button1").click(function(){
    $(this).text("Selected").css("background-color", "yellow");
    $("#variant-button2").text("Select").css("background-color", "white");
    $("#variant-button3").text("Select").css("background-color", "white");
   
  });


$("#variant-button2").click(function(){
    $(this).text("Selected").css("background-color", "yellow");
     $("#variant-button1").text("Select").css("background-color", "white");
    $("#variant-button3").text("Select").css("background-color", "white");
   
  });

$("#variant-button3").click(function(){
    $(this).text("Selected").css("background-color", "yellow");
     $("#variant-button2").text("Select").css("background-color", "white");
    $("#variant-button1").text("Select").css("background-color", "white");
   
  });


 $("#save").mouseenter(function(){
    $(this).css("background-color", "yellow");
   
  });
 $("#save").mouseleave(function(){
    $(this).css("background-color", "white");
   
  });


 $("#share").mouseenter(function(){
    $(this).css("background-color", "yellow");
   
  });


 $("#share").mouseleave(function(){
    $(this).css("background-color", "white");
   
  });

  
});